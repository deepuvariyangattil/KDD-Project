1. Convolutional Neural Network output screenshot is present inside Output_CNN folder.
2. For KNN,SVM,Random Forest and ANN models are implemented in ipython notebook. Hence output is present inside the notebook itself.
 